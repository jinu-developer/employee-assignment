export const API_URL={
    DEPARTMENT:'http://localhost:3000/api/department/',
    EMPLOYEE:'http://localhost:3000/api/employee/',
    PROFILEPHOTO:'http://localhost:3000/api/fileupload/',
    photosPath :`http://localhost:3000/profile/`,


    REGISTER:'http://localhost:3000/api/register/',
    LOGIN:'http://localhost:3000/api/login/',
    
}